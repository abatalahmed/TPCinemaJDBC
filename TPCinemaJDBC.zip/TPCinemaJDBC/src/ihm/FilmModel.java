package ihm;

import java.util.List;
import java.util.Vector;

import javax.swing.table.AbstractTableModel;

import metier.Film;







public class FilmModel extends AbstractTableModel{
	
private String[] nomColonnes=
new String[]{"#","Titre","Realisateur"};
private Vector<String[]> values=new Vector<String[]>();
			
		@Override
		public int getRowCount() {
			return values.size();
		}
		@Override
		public int getColumnCount() {
			return nomColonnes.length;
		}
		@Override
		public Object getValueAt(int rowIndex, int columnIndex) {
			return values.get(rowIndex)[columnIndex];
		}
		@Override
		public String getColumnName(int column) {
			// TODO Auto-generated method stub
			return nomColonnes[column];
		}
		
		
		public void setData(List<Film> films){
			values=new Vector<String[]>();
			String type="";
			for(Film f:films) {
				
				
				values.add(new String[]{
						f.getId()+"",
						f.getTitre(),
						f.getRealisateur()
						});
			}
		
			
			fireTableChanged(null);
		}
		}


