package ihm;

import java.awt.EventQueue;
import metier.Film;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import dao.CinemaJDBC;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.ActionEvent;

public class JFilm extends JFrame {

	private JPanel contentPane;
	private JTextField 	txtTitre = new JTextField();
	private JTextField 	txtRealisateur = new JTextField();

	
	private CinemaJDBC cinema;
	private JTable tableFilm;
	private FilmModel model;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JFilm frame = new JFilm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JFilm() {
		
		cinema=new CinemaJDBC();
		model=new FilmModel();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Titre");
		lblNewLabel.setBounds(42, 19, 61, 16);
		contentPane.add(lblNewLabel);
		
		JLabel lblRealisateur = new JLabel("Realisateur");
		lblRealisateur.setBounds(256, 19, 61, 16);
		contentPane.add(lblRealisateur);
		
	
		txtTitre.setBounds(30, 47, 130, 26);
		contentPane.add(txtTitre);
		txtTitre.setColumns(10);
		
		txtRealisateur.setColumns(10);
		txtRealisateur.setBounds(256, 47, 130, 26);
		contentPane.add(txtRealisateur);
		model.setData(cinema.consulterFilms());
		JButton btnNewButton = new JButton("Ajouter");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				if( !txtTitre.getText().equals("") &&  !txtRealisateur.getText().equals("")) {
					cinema.ajouterFilm(new Film(txtTitre.getText(), txtRealisateur.getText()));
					model.setData(cinema.consulterFilms());
					txtTitre.setText("");
					txtRealisateur.setText("");
				}else JOptionPane.showMessageDialog(null, "Champs Vides", "Error",JOptionPane.INFORMATION_MESSAGE);
			}
		});
		btnNewButton.setBounds(312, 83, 108, 29);
		contentPane.add(btnNewButton);
		
		//cinema.chargerFile("films.txt");
		model.setData(cinema.consulterFilms());
		tableFilm=new JTable(model);
		JScrollPane jspFilm = new JScrollPane(tableFilm);
		jspFilm.setBounds(42, 127, 374, 125);
		contentPane.add(jspFilm);
		
		JButton btnNewButton_1 = new JButton("Modifier");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(! txtTitre.getText().equals("") &&  !txtRealisateur.getText().equals("")) {
					cinema.modifierFilm(new Film(txtTitre.getText(), txtRealisateur.getText()),Integer.parseInt(tableFilm.getValueAt(tableFilm.getSelectedRow(), 0)+""));
					model.setData(cinema.consulterFilms());
					txtTitre.setText("");
					txtRealisateur.setText("");
					btnNewButton_1.setEnabled(false);
				}
				
			}
			
		});
		btnNewButton_1.setEnabled(false);
		btnNewButton_1.setBounds(214, 83, 103, 29);
		contentPane.add(btnNewButton_1);
		
		JButton btnSupp = new JButton("Supprimer");
		btnSupp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (tableFilm.getSelectedRow()>-1) {
					cinema.supprimerFilm(Integer.parseInt(tableFilm.getValueAt(tableFilm.getSelectedRow(), 0)+""));
					model.setData(cinema.consulterFilms());
					
				}else JOptionPane.showMessageDialog(null, "Aucun Ligne Selectionner", "Error",JOptionPane.ERROR_MESSAGE); 

			}
		});
		btnSupp.setBounds(111, 85, 108, 29);
		contentPane.add(btnSupp);
		
		JButton btnRechercher = new JButton("Rechercher");
		btnRechercher.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					
					model.setData(cinema.rechercherFilmParMC(txtTitre.getText()));
				
			}
		});
		btnRechercher.setBounds(-5, 83, 108, 29);
		contentPane.add(btnRechercher);
		
		tableFilm.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				if (e.getClickCount()==2) {
					txtTitre.setText(tableFilm.getValueAt(tableFilm.getSelectedRow(), 1)+"");
					txtRealisateur.setText(tableFilm.getValueAt(tableFilm.getSelectedRow(), 2)+"");
					btnNewButton_1.setEnabled(true);
				}
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
		});
		
	}
	
}
