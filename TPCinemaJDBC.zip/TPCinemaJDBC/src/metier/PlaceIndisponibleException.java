package metier;

public class PlaceIndisponibleException extends Exception {

	
	public PlaceIndisponibleException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
	

}
