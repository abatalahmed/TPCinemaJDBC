package metier;

public class SalleNormale  extends Salle{

	
	
	
	public SalleNormale(int numero,  String nom,int nbPlaces) {
		super(numero, nom, nbPlaces);
		// TODO Auto-generated constructor stub
	
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calculerPrix() {
		// TODO Auto-generated method stub
		return 30;
	}

}
