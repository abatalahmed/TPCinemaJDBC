package metier;

public interface IVendeurCinema extends IUserCinema{
	
	
	public void vendrePlaces(int nbPlace,String titre) throws PlaceIndisponibleException;

}
