package metier;

import java.util.Date;

public class Seance {
	
	
	private int id;
	private Date dateProjection;
	private int nbPlacesVendu;
	
	private Film film;
	private Salle salle;
	public Date getDateProjection() {
		return dateProjection;
	}
	public void setDateProjection(Date dateProjection) {
		this.dateProjection = dateProjection;
	}
	public int getNbPlacesVendu() {
		return nbPlacesVendu;
	}
	public void setNbPlacesVendu(int nbPlacesVendu) {
		this.nbPlacesVendu = nbPlacesVendu;
	}
	public Film getFilm() {
		return film;
	}
	public void setFilm(Film film) {
		this.film = film;
	}
	public Salle getSalle() {
		return salle;
	}
	public void setSalle(Salle salle) {
		this.salle = salle;
	}
	public Seance() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Seance(Date dateProjection) {
		super();
		this.dateProjection = dateProjection;
		this.nbPlacesVendu = 0;
	}
	
	
	public void vendrePlaces(int nbPlace) throws PlaceIndisponibleException{
		if (salle.getNbPlaces()>=(nbPlacesVendu+nbPlace)) {
			nbPlacesVendu+=nbPlace;
		}else throw new PlaceIndisponibleException("Place non dispo");
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	

}
