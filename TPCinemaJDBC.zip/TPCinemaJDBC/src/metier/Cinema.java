package metier;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.nio.Buffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Cinema implements IUserCinema,IVendeurCinema,IAdminCinema{
	
	
	
	private List<Film> films=new ArrayList<Film>();
	private List<Salle> salles=new ArrayList<Salle>();

	private List<Seance> seances=new ArrayList<Seance>();

	@Override
	public void ajouterFilm(Film f) {
		films.add(f);
		
	}

	@Override
	public void ajouterSalle(Salle s) {
		salles.add(s);
		
	}

	@Override
	public void ajouterSeance(Seance s) {
		seances.add(s);
		
	}

	@Override
	public double consulterCA() {
		double ca=0;
		for(Seance s:seances) {
			if (s.getSalle() instanceof SalleNormale) ca+=(s.getSalle().calculerPrix()*s.getNbPlacesVendu());
			if (s.getSalle() instanceof SalleVip) ca+=(s.getSalle().calculerPrix()*s.getNbPlacesVendu());

		}
		return ca;
	}

	@Override
	public double consulterTauxRemplissage(String t) {
		Film f=consulterFilmParTitre(t);
		double nbPlaceV=0;
		double nbPlace=0;
		double taux=0;
		
		if(f !=null) {
			
			
			for(Seance s:seances) {
				
				if(s.getFilm().getTitre().equals(t)) {
					
					nbPlace+=s.getSalle().getNbPlaces();
					nbPlaceV+=s.getNbPlacesVendu();
				}
			}
		}
		
		//System.err.println(nbPlace+" "+);
		
		taux=(nbPlaceV/nbPlace)*100;
		return taux;
	}

	@Override
	public void chargerFile(String chemin) {
		try {
			File f=new File(chemin);
			FileReader fr=new FileReader(f);
			BufferedReader br=new BufferedReader(fr);
			String ligne;
			while((ligne=br.readLine())!=null) {
				
				String[] flm=ligne.split(";");
				films.add(new Film(flm[0], flm[1]));
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void Serialiser(String chemin) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void vendrePlaces(int nbPlace,String titre) throws PlaceIndisponibleException {
		boolean check=false;
		if(consulterFilmParTitre(titre) !=null) {
			for(Seance s:seances) {
				if(s.getFilm().getTitre().equals(titre)) {
					if(s.getSalle().getNbPlaces()>=s.getNbPlacesVendu()+nbPlace) {
						s.setNbPlacesVendu(s.getNbPlacesVendu()+nbPlace);
						check=true;
						break;
					}else {
						continue;
					}
				}
			}
			
		}
		if(!check) throw new PlaceIndisponibleException("Pas de places dispo pour le file:"+titre);
	}

	@Override
	public Film consulterFilmParTitre(String titre) {
		Film f=null;
		for(Film f1:films) {
			if(f1.getTitre().equals(titre)) f=f1;
		}
		return f;
	}

	@Override
	public Salle consulterSalle(int num) {
		Salle s=null;
		for(Salle s1:salles) {
			if(s1.getNumero()==num) s=s1;
		}
		return s;
	}

	@Override
	public List<Film> consulterFilms() {
		// TODO Auto-generated method stub
		return films;
	}

	@Override
	public void acheterPlace(String titre) throws PlaceIndisponibleException {
		vendrePlaces(1, titre);
		
	}

}
