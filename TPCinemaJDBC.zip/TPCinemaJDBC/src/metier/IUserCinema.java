package metier;

import java.util.List;

public interface IUserCinema {
	

	
	
	
	
	public Film consulterFilmParTitre(String titre);
	
	public Salle consulterSalle(int num);
	public List<Film> consulterFilms();
	public void acheterPlace(String titre) throws PlaceIndisponibleException;

}
