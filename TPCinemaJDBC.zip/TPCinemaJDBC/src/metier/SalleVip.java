package metier;

public class SalleVip  extends Salle{

	
	
	
	public SalleVip(int numero,  String nom,int nbPlaces) {
		super(numero, nom, nbPlaces);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double calculerPrix() {
		return 60;
	}
	

}
