package metier;

import java.util.Date;

public class TestMetier {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		
		
		try {
			Cinema cinema=new Cinema();
			
			
			
			cinema.chargerFile("films.txt");
			cinema.ajouterFilm(new Film("X3D", "Moi"));
			cinema.ajouterSalle(new SalleNormale(1, "",100));
			cinema.ajouterSalle(new SalleVip(2,"", 50));
			Seance s=new Seance(new Date());
			cinema.ajouterSeance(s);
			s.setFilm(cinema.consulterFilmParTitre("X3D"));
			s.setSalle(cinema.consulterSalle(1));
			
			
			cinema.vendrePlaces(25, "X3D");
			
			System.out.println("Taux Remplissage pour X3D:"+cinema.consulterTauxRemplissage("X3D"));
			
			System.out.println("CA : "+cinema.consulterCA());
			System.out.println(cinema.consulterFilms().size());
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
