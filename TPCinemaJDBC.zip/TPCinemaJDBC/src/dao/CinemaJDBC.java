package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import metier.Film;
import metier.IAdminCinema;
import metier.IVendeurCinema;
import metier.PlaceIndisponibleException;
import metier.Salle;
import metier.SalleNormale;
import metier.SalleVip;
import metier.Seance;

public class CinemaJDBC implements IAdminCinema,IVendeurCinema {
	
	
	Connection conn=SingletonConnection.getConnection();
	
	@Override
	public Film consulterFilmParTitre(String titre) {
		Film f=null;
		try {

			PreparedStatement ps=conn.prepareStatement("select * from films where titre=?");
			ps.setString(0, titre);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				f=new Film(rs.getString(2), rs.getString(3));
				f.setId(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}

	@Override
	public Salle consulterSalle(int num) {
		Salle s=null;
		try {

			PreparedStatement ps=conn.prepareStatement("select * from salles where num=?");
			ps.setInt(1, num);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				if (rs.getString("type").equals("VIP")) {
					s=new SalleVip(rs.getInt(1), rs.getString(2), rs.getInt(3));
				}else s=new SalleNormale(rs.getInt(1), rs.getString(2), rs.getInt(3));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return s;
	}

	@Override
	public List<Film> consulterFilms() {
		List<Film> films=new ArrayList<Film>();
		try {

			PreparedStatement ps=conn.prepareStatement("select * from films");
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				Film f=new Film(rs.getString(2), rs.getString(3));
				f.setId(rs.getInt(1));
				films.add(f);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return films;
	}
	
	
	
	public Seance consulterSeanceParFilm(String titre) {
		
		Seance s=null;
		int idF = 0,idS = 0;
		try {

			PreparedStatement ps=conn.prepareStatement("select * from seances where idFilm=(select id from films where titre=?)");
			ps.setString(1, titre);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				s=new Seance();
				s.setId(rs.getInt(1));
				s.setDateProjection(rs.getDate(2));
				s.setNbPlacesVendu(rs.getInt(3));
				idF=rs.getInt(4);
				idS=rs.getInt(5);
				
			}
			
			s.setFilm(getFilmById(idF));
			s.setSalle(consulterSalle(idS));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return s;
	}

	private Film getFilmById(int idF) {
		Film f=null;
		try {

			PreparedStatement ps=conn.prepareStatement("select * from films where id=?");
			ps.setInt(0, idF);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()) {
				f=new Film(rs.getString(2), rs.getString(3));
				f.setId(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}

	@Override
	public void acheterPlace(String titre) throws PlaceIndisponibleException {
		
		try {
			Seance s=consulterSeanceParFilm(titre);
			if (s.getSalle().getNbPlaces()>=(s.getNbPlacesVendu()+1)) {
				PreparedStatement ps=conn.prepareStatement("update seances set 	nbPlacesVendu=	nbPlacesVendu+1 where id=?");
				ps.setInt(1, s.getId());
				ps.executeUpdate();
			} else throw new PlaceIndisponibleException("Place indisponible");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void vendrePlaces(int nbPlace, String titre) throws PlaceIndisponibleException {
		try {
			Seance s=consulterSeanceParFilm(titre);
			if (s.getSalle().getNbPlaces()>=(s.getNbPlacesVendu()+nbPlace)) {
				PreparedStatement ps=conn.prepareStatement("update seances set 	nbPlacesVendu=	nbPlacesVendu+ ? where id=?");
				ps.setInt(2, s.getId());
				ps.setInt(1, nbPlace);
				ps.executeUpdate();
			} else throw new PlaceIndisponibleException("Place indisponible");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void ajouterFilm(Film f) {
		
		try {
			PreparedStatement ps=conn.prepareStatement("INSERT INTO `Films` (`titre`, `realisateur`) VALUES ( ?, ?)");
			ps.setString(1,f.getTitre() );
			ps.setString(2, f.getRealisateur());
			ps.executeUpdate();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void ajouterSalle(Salle s) {
		// TODO Auto-generated method stub
		try {
			String type="VIP";
			if(s instanceof SalleNormale) type="Normal";
			
			PreparedStatement ps=conn.prepareStatement("INSERT INTO `Salles` ( `nom`, `nbPlaces`, `type`) VALUES ( ?, ?, ?);");
			ps.setString(1,s.getNom() );
			ps.setInt(2, s.getNbPlaces());
			ps.setString(3, type);
			ps.executeUpdate();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void ajouterSeance(Seance s) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double consulterCA() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double consulterTauxRemplissage(String titre) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void chargerFile(String chemin) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Serialiser(String chemin) {
		// TODO Auto-generated method stub
		
	}

	public void modifierFilm(Film f, int id) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement ps=conn.prepareStatement("UPDATE Films SET  titre=?, realisateur=? where id=?");
			ps.setString(1,f.getTitre() );
			ps.setString(2, f.getRealisateur());
			ps.setInt(3, id);
			ps.executeUpdate();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void supprimerFilm(int id) {
		// TODO Auto-generated method stub
		try {
			PreparedStatement ps=conn.prepareStatement("delete from Films where id=?");
			
			ps.setInt(1, id);
			ps.executeUpdate();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<Film> rechercherFilmParMC(String mc) {
		
		List<Film> films=new ArrayList<Film>();
		try {

			PreparedStatement ps=conn.prepareStatement("select * from films where titre like ? or realisateur like ?");
			ps.setString(1, "%"+mc+"%");
			ps.setString(2, "%"+mc+"%");
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {

				Film f=new Film(rs.getString(2), rs.getString(3));
				f.setId(rs.getInt(1));
				films.add(f);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return films;
		
	}

}
