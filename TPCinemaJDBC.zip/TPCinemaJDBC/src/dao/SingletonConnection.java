package dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class SingletonConnection 
{
	private static Connection conn=null;
	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn=DriverManager.getConnection
					("jdbc:mysql://127.0.0.1:8889/tpCinema","tpgi","123456");
		//JOptionPane.showMessageDialog(null,"creation d une connection");
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static Connection getConnection()
	{
		return conn;
	}
}
